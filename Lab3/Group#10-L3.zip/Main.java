import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
import java.lang.*;
import java.util.Collections;
import java.text.DecimalFormat;

/**
    @author Francisco Rivera
    @author Matthew Zaldaña
    @version Lab 3 1.0
    @since 9/8/2020
*/

class Main {

	/**
    Main displays menu

    @param usStates is the ArrayList for the states in the .txt file
    @param populations is the ArrayList for the populations in .txt file for respective states
    @param choice is the user's input
    @func calls respective functions
  */
	public static void main(String[] args) {
    	Scanner in = new Scanner(System.in);

		ArrayList<String> usStates = new ArrayList<String>();
		ArrayList<Integer> populations = new ArrayList<Integer>();

		readFile(usStates, populations);
		

		String choice;
		do {
			displayMenu();
			choice = in.next();
			switch(choice) {
				case "1":
					sortStates(usStates, populations);
					break;
				case "2":
					sortPopulation(usStates, populations);
					break;
				case "3":
					totalSum(populations);
					break;
				case "4":
					medianState(usStates, populations);
					break;
				case "5":
					populationGreater(usStates, populations);
					break;
				case "6":
					System.out.println("Program has shut down");
					return;
				default:
					System.out.println("Invalid Input");
					break;				
			}			
		} while (choice != "6"); 
	

}

	/**
    readFile Method reads the states.txt file

    @param read will scan each line
    @param counter is set to keep track of object type to help store items in respective ArrayList  
    @param contents is an array that stores all the items in the file
	@func try-catch will catch exception if file cannot be found
    */
	public static void readFile(ArrayList<String> states, ArrayList<Integer> pops) {  
		try {
			Scanner read = new Scanner(new File("StatePops.txt"));
			int counter = 0;
			while (read.hasNext()) {
				String line = read.nextLine();
				String[] contents = line.split(",");

				for (int i = 0; i < contents.length; i++) {
					if (counter == 0) {
						states.add(contents[i]);
						counter++;
					} else {
						pops.add(Integer.parseInt(contents[i]));
						counter = 0;
					}	
				}

			}
			read.close();
			} catch (FileNotFoundException fnf) {
				System.out.println("File not found.");
			}
	}

	/**
    sortStates Method sorts the states in alphabetical order 
	
    @param swapped will change once a state has been sorted
    @param swapState will temp store state that needs to be swapped  
    @param swapPop will temp store pop for respective swapState that needs to be swapped
	@func displayStates will call displayStates func to display the states
    */ 
	public static void sortStates(ArrayList<String> states, ArrayList<Integer> pops) {
		boolean swapped = false;
		do {
			swapped = false;
			for (int i = 0; i < states.size()-1; i++) {
				if (states.get(i).compareTo(states.get(i+1)) > 0) {
					String swapState = states.get(i);
					int swapPop = pops.get(i);

					states.set(i, states.get(i+1));
					pops.set(i, pops.get(i+1));

					states.set(i+1, swapState);
					pops.set(i+1, swapPop);
					
					swapped = true;
				}
			}
		} while(swapped);
		displayStates(states, pops);
	}

	/**
    sortPopulation Method sorts the population from low to high 
	
    @param swapped will continue to sort population until it returns false
    @param swapState will temp store state that needs to be swapped  
    @param swapPop will temp store pop for respective swapState that needs to be swapped
	@func displayStates will call displayStates func to display the states
    */ 
	public static void sortPopulation(ArrayList<String> states, ArrayList<Integer> pops) {
		boolean swapped = false;
		do {
			swapped = false;
			for (int i = 0; i < pops.size()-1; i++) {
				if (pops.get(i) > pops.get(i+1)) {
					String swapState = states.get(i);
					int swapPop = pops.get(i);

					states.set(i, states.get(i+1));
					pops.set(i, pops.get(i+1));

					states.set(i+1, swapState);
					pops.set(i+1, swapPop);
					
					swapped = true;
				}
			}
		} while(swapped);
		
		displayStates(states, pops);	
	}

	/**
    displayStates Method sorts the states in alphabetical order 
	
    @param df make a new DecimalFormatter in the order of billions
	@func for loop will iterate through all elements and include commas for populations
    */
	public static void displayStates(ArrayList<String> states, ArrayList<Integer> pops) {
		DecimalFormat df = new DecimalFormat("###,###,###,###.##");
		for (int i = 0; i < states.size(); i++) {
			System.out.println(states.get(i) + "\t" + df.format(pops.get(i)));
		}
	}	
	
	/**
    totalSum Method sorts the states in alphabetical order 
	
    @param df make a new DecimalFormatter in the order of billions
    @param sum is a counter that will keep summing populations 
    */ 
	public static void totalSum(ArrayList<Integer> pops) {
		DecimalFormat df = new DecimalFormat("###,###,###,###.##");
		int sum = 0;
		for (int i = 0; i < pops.size(); i++) {
			sum = sum + (pops.get(i));
		}
		System.out.println("Total Population: " + df.format(sum));
	}
	
	/**
    populationGreater Method displays all populations greater than the value entered by the user 
	
    @param df make a new DecimalFormatter in the order of billions
    @param population will store the number the user enters  
    */ 
	public static void populationGreater(ArrayList<String> states, ArrayList<Integer> pops) {
		DecimalFormat df = new DecimalFormat("###,###,###,###.##");
		Scanner in = new Scanner(System.in);
		System.out.println("Please enter a polulation to display all states and their populations that are larger.");
		int population = in.nextInt();
		for (int i = 0; i < pops.size(); i++) {
			if(pops.get(i) > population) {
				System.out.println(states.get(i) + "\t" + df.format(pops.get(i)));
			}
		}
	}
	
	/**
    displayMenu Method displays the menu the user can interact with
    */
	public static void displayMenu() {
		System.out.println("State Stats");
		System.out.println("1. Display Sorted States");
		System.out.println("2. Display Sorted Populations");
		System.out.println("3. Display Total US Population");
		System.out.println("4. Display Median State(s)");;
		System.out.println("5. Display States with Population Greater Than");
		System.out.println("6. Quit");
	}

	/**
    medianState Method displays the state with the median population
	
    @param index1 will return the state with the first median polulation if sortPopulation func is even
    @param index2 will return the state with the second median polulation if sortPopulation func is even  
    @param index will return the state with the  median polulation
	@func sortPopulation will sort the states based on polulation
    */
	public static void medianState(ArrayList<String> states, ArrayList<Integer> pops) {
		if ((pops.size() % 2) == 0) {
			sortPopulation(states, pops);
			int index1 = pops.size() / 2;
			System.out.println("Median state 1: " + states.get(index1) + "\t" + pops.get(index1));
			System.out.println("Median state 2: " + states.get(index1 + 1) + "\t" + pops.get(index1 + 1));	
		}
		else {
			sortPopulation(states, pops);
			int index = (pops.size() / 2);
			System.out.println("Median state: " + pops.get(index));
		}	
	}
}