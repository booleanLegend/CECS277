import java.util.Scanner;

class Main {
	public static void main(String[] args) {
		Player dice = new Player();
		dice.rollDice();
		System.out.println(dice);
		
		if (dice.threeOFaKind()) {
			dice.points += 3;
			System.out.println("You got 3 of a kind! Score " + dice.points + ".");	
		}
		else if (dice.pairRoll()) {
			dice.points ++;
			System.out.println("You got a pair! Score = " + dice.points + ".");	
		}
		else if (dice.series()) {
			dice.points += 2;
			System.out.println("You got a series! Score = " + dice.points + ".");	
		}
		else {
			System.out.println("Aww. Too bad! Score = " + dice.points + ".");
		}
    	System.out.println("Play Again(Y/N)");
		boolean ans = CheckInput.getYesNo();
		
		while (ans != false){
			dice.takeTurn();
      		System.out.println("Play Again(Y/N)");
      		ans = CheckInput.getYesNo();
		}
    	System.out.println("Final Score: " +dice.points+ " Points");
	}
}