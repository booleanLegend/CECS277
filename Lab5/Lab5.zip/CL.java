/*

CECS 277– Lab 5													Name: _______________________
Yahtzee

Necessary Components:
	Done x / .5			1.   Created three classes in one project folder (Die, Player, Main).
	______ /  1			2.   Die class has lecture notes code plus lessThan and equals.
	Done x / .5			3.   Player class has array of three Die objects, and int points.
	______ / .5			4.   Player has method to sort dice that uses Die’s lessThan method.
	______ /  1			5.   Made methods to check for wins using equals when able.
	Done x / .5			6.   Made takeTurn(), getPoints() and toString().
	Done x / .5			7.   Main has a Player object and repeats game in a while loop.
	
Output:			
	______ / .5			8.   Detects a pair.
	______ / .5			9.   Detects a series.
	______ / .5			10.  Detects a three-of-a-kind.
	______ / .5			11.  Points are accumulated and displayed correctly.
	______ / .5			12.  Game repeats until user chooses to quit, displays final points.
	______ / .5			13.  User input is checked for invalid values.
	
Formatting:						
	______ /  1			14.  Javadoced all classes, instance variables, and methods.
	______ / .5			15.  Main and functions are correctly documented.
	______ / .5			16.  Program has meaningful variable and method names.
	______ / .5			17.  Program has correct tabs and spacing.
	
Total:							
	______ / 10 Points

*/