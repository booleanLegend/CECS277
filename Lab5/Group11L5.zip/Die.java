/** Class Die constructs a single die while also constructing 
*   methods of roll, diplay, lessThan, and equal to 
*/
public class Die {
	/** num of sides on die */
	private int sides;
	/** The value of the die */
	private int value;
	/**
	* Creates a 6-Sided Dice
	*/
	public Die(){
		this.sides = 6;
		this.value = 1;
	}
	/**
	* Creates a die with sides number of sides 
	* @param sides of sides of die
	*/
	public Die(int sides){
		this.sides = sides;
		this.value = 0;
	}
	/** Rolls a die 
	*   @return rolled value of the die
	*/
	public int roll() {
		value = ((int)(Math.random()* sides) +1);
		return value;
	}
	/** returns the value of the die
	*   @return returns the value of the die
	*/
	public int getValue(){
		return value;
	}
	/** Function sets values of the dice
  	*   @param val value to assign
	*   @return returns true or false base on 
	*/
	public boolean setValue(int val){
		if (val >= 1 && val <= sides) {
			value = val;
			return true;
		}
		return false;
	}
	/** 
	* displays the value of the die
	*/
	public void displayDie() {
		System.out.println(value);
	}
	/** returns string representation of the die
	*   @return string representation of the die
	*/
	public String toString(){
		return " "+value;
	}
	/** Equals checks whether value is equal to instance variable
	*   @param value - Comparason value for this.value
	*   @return true or false if value is equal to each other
	*/
	public boolean equals(int value){
		if (this.value == value) {
		return true;
		}
		return false;
	}
	/** Equals checks whether value is less than to instance variable
	*   @param value - Comparason value for this.value
	*   @return true or false if value is equal to each other
	*/
	public boolean less_than(int value) {
		if (this.value < value){
		return true;
		}
		return false;
	}
}