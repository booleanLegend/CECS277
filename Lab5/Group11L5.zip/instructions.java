/*

							CECS 277 – Lab 5
								Yahtzee

Create a dice game that uses the Die class that was given in Lecture 5. Create a new class called Die in a file called ‘Die.java’, add the code from the lecture notes, and then add an equals method and a less than method that returns true if the implicit parameter is less than the explicit parameter and false otherwise. In the same project folder, create a second class called Player in a file called ‘Player.java’ (the code for this class is not in the lecture notes). Then, again in the same project folder, create a third class for your main.

The player rolls a set of 3 dice. If two of the dice are the same then the player receives 1 point for a pair. If all of the dice are the same, then the player receives 3 points for 3-of-a-kind (note: if a player gets a 3-of-a-kind they shouldn’t also get points for having a pair). If the dice values are in a series, then the player receives 2 points (ex. 1-2-3, 3-2-1, 2-1-3, or any other order of these values would be considered a series).

Create an array of three dice objects and a variable for the player’s points in your Player class. In the constructor, loop through and call the constructor for each of the dice to initialize them. Create a sort method that arranges the dice in ascending order that uses the less than method you wrote in the Die class. Add three methods to check for each of the three different win types (use the Die’s equals method when possible), return true if they met the win condition. Add a toString() method for your Player class that will be used to display the dice roll (ex. D1=2, D2=4,D3=6). Add a get method for the point value. Create a method that calls takeTurn that rolls the dice, prints their values using the toString() function you wrote (you can use System.out.println(this) to call it from within takeTurn()), and determines if the player met any of the win conditions, if so, then accumulate those points in their point total and display it.

Ask the player if they want to continue playing after every roll, display their final points when they decide to quit. 

Check the user’s input to ensure that it is valid.

Example Output:
Yahtzee

Rolling Dice...D1=2,D2=3,D3=5
Awww. Too Bad.Score = 0 points.
Play again? (Y/N) X
Invalid input.Play again? (Y/N) Y
Rolling Dice...D1=2,D2=3,D3=4
You got a series of 3! Score = 2 points.
Play again? (Y/N) Y
Rolling Dice...D1=1,D2=1,D3=3
You got a pair! Score = 3 points.
Play again? (Y/N) Y
Rolling Dice...D1=4,D2=4,D3=4
You got 3 of a kind! Score = 6 points.
Play again? (Y/N) Y
Rolling Dice...D1=1,D2=3,D3=6
Awww. Too Bad.
Score = 6 points.Play again? (Y/N) N
Game Over.
Final Score = 6 points
*/