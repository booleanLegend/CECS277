import java.util.Arrays;
/**
*@Class Player Class - Creates a player object that will track instant variables dice 
* array and amt of dice, plus public points to access outside of Player class. The 
* class also has methods for checking wins and updating points
*/
public class Player {
	/** 
	* Initializing the amount of dice in Yahzee game
  	*/
	private final int NUM_DICE = 3;
	/** 
	* Creating a set of dice for the game 
	*/
	private Die[] dice;
	/** 
	* Creating a set of Points for the game
	*/
	public int points;
	/** 
	* Constructor that will set a 3 Dice objects and set them equal to the array. 
	* @param dice dice is a Die object
	*/
	public Player() {
		dice = new Die[NUM_DICE];
		for (int d = 0; d < dice.length; d++) {
			dice[d] = new Die();
		}
    	this.points = 0;
	}
	/** String representation of the dice object.
	*   @return a string representation of the dice 
	*/
	@Override
	public String toString() {
		String values = "";
		for (int d = 0; d < dice.length; d++) {
			values += "D" + (d + 1) + ": " + dice[d] + " ";

		}
		return values;
	}
	/** 
	* Rolls a die 
  	*/
	public void rollDice() {
		for (int d = 0; d < dice.length; d++) {
			dice[d].roll();
		}
	}

	/**
	* Sorts the dice array in ascending order where minimum(i)
	* equals the length of the list. Then afterwards we display the 
	* new list from min which is now equal to j. Creates a new ordered list
	* @param min is a index value that allows testing of each value and is looped
	* into updated list
	*/
	public void sort() { 
		for(int i = 0; i < this.dice.length; i++){
			int min = i;
			for(int j = i + 1 ; j < this.dice.length; j++){
				if(this.dice[j].less_than(this.dice[min].getValue())) {
					min = j;
        		}
		 	}
			Die newArry = dice[min];
			this.dice[min] = this.dice[i];
			this.dice[i] = newArry;
		}
	}
	/** 
	* getPtValue Gets the point values
  	*/
	public int getPtValue() {
		return points;
	}
	 	
	/** 
	* threeOFaKind will return a boolean if elements in dice array are all equal
	*/
	public boolean threeOFaKind() {
		if (this.dice[0].getValue() == this.dice[1].getValue() && this.dice[0].getValue() == this.dice[2].getValue()) {
			return true;
		}
		return false;
	}
	
	/**
	*pairRoll will return a boolean if any two elements in dice array are equal
	@param dice12 holds a boolean from comparing the first two dice elements
	@param dice23 holds a boolean from comparing the last two dice elements
	*/
	public boolean pairRoll() {
		boolean dice12 = this.dice[0].equals(this.dice[1].getValue());
		boolean dice23 = this.dice[1].equals(this.dice[2].getValue());
		boolean dice13 = this.dice[0].equals(this.dice[2].getValue());
		if (dice12 || dice23 || dice13) {    
			return true;
		}	
		return false;	
	}
	
	/**
	* series will return a boolean after sorting the elements in ascending order and checking 
	* whether they are all in series of each other
	* @param arry arry holds values from the dice array
	*/
	public boolean series() {
		//array for each values
		int arry [] = {this.dice[0].getValue(), this.dice[1].getValue(), this.dice[2].getValue()};
		Arrays.sort(arry);
		//if (arr2 - arr1 = 1 and arr3 - arr1 = 2)
		if ((arry[2] - arry[1] == 1) && (arry[2] - arry[0] == 2)){
			return true;
		}
		return false;
	}
	
	/**
	* takeTurn() will roll the dice, print their values, check for winning by calling the 
	* respective method and update points
	*/
	public void takeTurn() {
		// Rolls the dice
		for (int d = 0; d < dice.length; d++) {
			dice[d].roll();
		}
		System.out.println(this.toString());

		// This type of win is for when all 3 dice are the same
		if (threeOFaKind()) {
			points += 3;
			System.out.println("You got 3 of a kind! Score " + points + ".");
		}
		// This type of win is for when two dice are the same
		else if (pairRoll()) {
			points ++;
			System.out.println("You got a pair! Score = " + points + ".");	
		}
		// This type of win is for when the dice are in series, using the sort method
		else if (series()) {
			points += 2;
			System.out.println("You got a series of 3! Score = " + points + ".");
		}
		// This is for no win
		else {
			points += 0;
			System.out.println("Awww. Too Bad. Score = " + points + ".");
		}
	}
}